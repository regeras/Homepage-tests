function closeCookiesMessage() {
    $(".cookies").fadeOut(300)
}

function subscribeNews() {
    var form = $("#subscribe_popup");
    "" === form.find("input").val() ? form.addClass("error") : (form.removeClass("error").addClass("success"), setTimeout(function() {
        form.fadeOut(300), setTimeout(function() {
            $.magnificPopup.instance.close()
        }, 200)
    }, 1500))
}