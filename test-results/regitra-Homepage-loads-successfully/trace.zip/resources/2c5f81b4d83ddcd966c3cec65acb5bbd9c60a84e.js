var resize = false;

$( document ).ready( function(){

    // disabilities version
    $('#disabilites_version').on('click','a.dis_actions',function(){
        var value_key = $(this).data("key");
        var value = $(this).data("value");
        if(value_key == "size"){
            $('body').removeClass('size-1 size-2 size-3');
            $('#disabilites_version a.size').removeClass("active");
        }else if(value_key == "bg"){
            $('body').removeClass('bg-white bg-black');
            $('#disabilites_version a.bg').removeClass("active");
        }else if(value_key == "img"){
            $('body').removeClass('img-show img-hide');
            $('#disabilites_version a.img').removeClass("active");
        }
        $(this).addClass("active");
        $('body').addClass(value_key + '-' + value);
        $.get('/general/disabilites/action.'+value_key + '-' + value+'/');
    });

    $('select.select' ).select2({});
    $('.form_item.select select' ).select2({});

    if (typeof $.fn.magnificPopup !== 'undefined') {
        $( '.news_inner .subscribe a, .all_news .subscribe a' ).magnificPopup({
            type:'inline',
            midClick: true
        });

        $( '.form_popup' ).magnificPopup({
            type:'iframe',
            midClick: true
        });
    } else {
        console.error("Fuction magnificPopup doesn't exist");
    }


    // Sliders logic
    if ($('.image_gallery_holder').length > 0) {

        $('.image_gallery_holder').each(function(){

            var globalThis = $(this);

            var newsSlider = $(this).find('.slider');
            var newsSliderThumbs = $(this).find('.thumbs');

            if (newsSlider.length && newsSliderThumbs.length) {

                $(this).find('.image_gallery').clone().appendTo($(this).find('.image_gallery_modal'));
                $(this).find('.image_gallery_modal').find('.image_gallery').removeClass('image_gallery').addClass('image_gallery_clone');

                var clone = $(this).find('.image_gallery_clone');
                var cloneSlider = clone.find('.slider');
                var cloneThumbs = clone.find('.thumbs');
                var prevSlideClone = clone.find('.nav .prev');
                var nextSlideClone = clone.find('.nav .next');

                var prevSlide = $(this).find('.image_gallery .nav .prev');
                var nextSlide = $(this).find('.image_gallery .nav .next');

                cloneSlider.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: true,
                    fade: true,
                    asNavFor: cloneThumbs,
                    prevArrow: prevSlideClone,
                    nextArrow: nextSlideClone
                });
                cloneThumbs.slick({
                    slidesToShow: 7,
                    slidesToScroll: 1,
                    asNavFor: cloneSlider,
                    arrows: false,
                    centerMode: false,
                    draggable: false,
                    focusOnSelect: true
                });

                clone.prepend('<div class="top"><div class="name"><span></span><div>-</div></div><div class="close">Uždaryti</div></div>');
                cloneThumbs.find('.slick-list').prepend('<div class="curr_image"><span></span>nuotrauka</div>');

                var cloneTop = clone.find('.top');
                var currImage = cloneThumbs.find('.curr_image');

                function slickRenew() {

                    var imageName = clone.find('.slider .slick-current.slick-active').attr('data-title');
                    var slidesLenght = cloneSlider.find('.slick-track li').length;
                    var currentSlide = clone.find('.slider .slick-current.slick-active').attr('data-slick-index');
                    var counterText = (parseInt(currentSlide) + 1) + '/' + slidesLenght;

                    currImage.find('span').text(counterText);
                    cloneTop.find('.name span').text(counterText);

                    cloneTop.find('.name div').text(imageName);
                }

                setTimeout(slickRenew(), 0);

                cloneSlider.on('afterChange', function (event, slick, currentSlide, nextSlide) {
                    var iframeSpan = $(slick.$slides.get(currentSlide)).find('span');
                    if(iframeSpan)
                    {
                        console.log(iframeSpan.next('iframe').length);
                        if(iframeSpan.next('iframe').length == 0)
                        {
                            var iframeData = iframeSpan.data('iframe');
                            if (iframeData) {
                                $(iframeData).insertAfter(iframeSpan);
                            }
                        }
                    }
                    slickRenew();
                });

                newsSlider.on('afterChange', function (event, slick, currentSlide, nextSlide) {
                    var iframeSpan = $(slick.$slides.get(currentSlide)).find('span');
                    if(iframeSpan)
                    {
                        if(iframeSpan.next('iframe').length == 0)
                        {
                            var iframeData = iframeSpan.data('iframe');
                            if (iframeData) {
                                $(iframeData).insertAfter(iframeSpan);
                            }
                        }
                    }
                });

                newsSlider.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: false,
                    fade: true,
                    asNavFor: newsSliderThumbs,
                });
                newsSliderThumbs.slick({
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    asNavFor: newsSlider,
                    draggable: false,
                    focusOnSelect: true,
                    centerMode: true,
                    prevArrow: prevSlide,
                    nextArrow: nextSlide
                });

                newsSlider.prepend('<div class="zoom"></div>');
                var zoomBtn = newsSlider.find('.zoom');
                var closeBtn = clone.find('.close');

                zoomBtn.on('click', function () {

                    var activeSlide = newsSlider.find('.slick-track li.slick-current.slick-active').attr('data-slick-index');

                    globalThis.find('.image_gallery_modal ').fadeIn(300,
                        function () {
                            $(this).resize();
                        }
                    );

                    cloneSlider.slick('slickGoTo', 2, true);
                    cloneSlider.slick('slickGoTo', activeSlide, true);
                });

                closeBtn.on('click', function () {

                    $(this).parents('.image_gallery_holder').find('.image_gallery_modal ').fadeOut(300);
                });

            }
        });
    }
    // Regular slider

    var regularSliderHolder = $( '.regular_slider_holder' );
    var regularSlider = $( '.regular_slider' );

    if ( regularSlider.length ) {

        regularSlider.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true,
        });

        var slideH = $('.text_slider_holder').find('li.slick-slide').first().height();
        var slideH = parseInt((parseInt(slideH)/2)-22);
        $('.text_slider_holder > ul > button.slick-arrow').css('top',slideH+'px');


        regularSlider.on('afterChange', function (event, slick, currentSlide, nextSlide) {
            //var iframeSpan = $(slick.$slides.get(currentSlide)).find('span');
            var slideSelector = $(slick.$slides.get(currentSlide));
            var slideHeight = parseInt((parseInt(slideSelector.height())/2)-22);
            $("html, body").animate({ scrollTop: slideSelector.offset().top }, 500);

            $('.text_slider_holder > ul > button.slick-arrow').css('top',slideHeight+'px');
        });
    }


    // Accordion

    $( '.accordion .title' ).on( 'click', function(){

        $( this ).toggleClass( 'active' ).next( '.collapse' ).slideToggle( 300 );
    });


    // Burger

    var burger = $( '.header .burger' );

    burger.on( 'click', function(){

        $( '.header [data-mobile-menu]' ).slideToggle( 300 );
    });







    //sliders
    if((typeof $.fn.lightSlider) != 'undefined')
    {
        //http://sachinchoolur.github.io/lightslider/settings.html
        var slider_index = 0;

        $('.slider-widget').each(function(){
            slider_index++;
            var LS_wrap = $(this);
            var LS_ul = LS_wrap.find('ul');
            var dataParams = ['pager', 'controls', 'loop', 'auto', 'item', 'drag', 'move', 'responsive', 'pause'];
            var LS_params = {
                item:1,
                pause: typeof $(this).data('pause') === 'number' ? $(this).data('pause') : 5000,//The time (in ms) between each auto transition
                auto: typeof $(this).data('auto') === 'boolean' ? $(this).data('auto') : true, //number of slides to show at a time
                loop:  typeof $(this).data('loop') === 'boolean' ? $(this).data('loop') : true, // 	If false, will disable the ability to loop back to the beginning of the slide when on the last element.
                mode: 'slide',
                slideMove: 1,
                speed: typeof $(this).data('pause') === 'number' ? $(this).data('speed') : 600,//Transition duration (in ms). // ex = speed:400;
                pauseOnHover: true, //Pause autoplay on hover.
                slideEndAnimation: false,
                controls: typeof $(this).data('controls') === 'boolean' ? $(this).data('controls') : true,
                slideMargin: 0,
                pager: typeof $(this).data('pager') === 'boolean' ? $(this).data('pager') : false,
                autoSize: false,
                adaptiveHeight: false,
                prevHtml: '<i class="fa fa-angle-left"></i>',
                nextHtml: '<i class="fa fa-angle-right"></i>',
                onBeforeSlide: function (el) {
                    $(el).parent().scrollLeft(0);
                },
            };
            var initParams = function(key){
            };
            var dataParamsLength = dataParams.length;
            var slider_key = (LS_wrap.data('sliderkey')) ? LS_wrap.data('sliderkey') : 'LSlider_' + slider_index;

            LS_wrap.data('sliderkey', slider_key);

            for(var i = 0; i < dataParamsLength; i++)
            {
                initParams(dataParams[i]);
            }

            if(LS_wrap.data('count') && (LS_ul.find('>li').length > 1))
            {
                LS_params.onBeforeSlide = function (el) {
                    LS_wrap.find('.slide_current').text(el.getCurrentSlideCount());
                }
            }

            window[slider_key] = LS_ul.lightSlider(LS_params);

            LS_wrap.find('.lSPrev,.lSNext').each(function(){
                $(this).attr('tabindex', 0);
            }).on('keyup', function(e){
                var key = (e.keyCode || e.which);
                //Enter
                if(key == 13) {
                    $(this).trigger('click');
                }
            });

            if(hasTouch() && ((typeof $.fn.swipe) != 'undefined'))
            {
                LS_wrap.swipe({
                    swipeLeft:function(event, direction, distance, duration, fingerCount, fingerData, currentDirection){
                        window[slider_key].goToNextSlide();
                    },
                    swipeRight:function(event, direction, distance, duration, fingerCount, fingerData, currentDirection) {
                        window[slider_key].goToPrevSlide();
                    }
                });
            }

            $(window).resize(function()
            {
                if (LS_ul.length) {
                    window[slider_key].refresh();
                }
            });
        });
    }



    //---------------------------------------------------------

    $('form.export_form').each(function() {
        var jForm = $(this);
        jForm.find('.export_link').on('click', function() {

            jForm.submit();

            return false;
        });
    });
    //---------------------------------------------------------

    if(window.innerWidth > 990)
    {
        moveMenu();
    }
    else {
        mobileFunctions();
    }
    //---------------------------------------------------------
});

jQuery(window).resize(function(){

    if(window.innerWidth > 990 && !resize)
    {
        moveMenu();
    }
    else{
        mobileFunctions();
    }
});
//---------------------------------------------------------

//actions in mobile rezolution
function mobileFunctions()
{
     //sub menu isskleidimas
     $('.header li.has_submenu > a').click(function(){
         return false;
     });

     //search toggle
     $('.icon_search.mob, span.mob').click(function(){
        $(this).parent().toggleClass('active');
     });
}

function moveMenu()
{
    resize = true;
    //pagrindiniu meniu punktu kurie nebetelpa perkelimas i Daugiau sub meniu
    var width = 0;
    var countItems = 0;
    var simpleItemsCount = 0
    if(window.innerWidth < 1180)
    {
        var breakPoint = 670;
    }
    else
    {
        var breakPoint = 840;
    }
    var itemsWithIcons = []; //meniu puntai su ikonom
    var itemsSimple = []; //meniu puntai be ikonu
    jQuery('li.main_nav').each(function(){
        width = width + parseInt(jQuery(this).innerWidth());

        if(width > breakPoint)
        {
            //elementams kurie nebetelpa i viena eilute priskiriam klase "move-item"

            if(jQuery(this).find('i').length)
            {
                itemsWithIcons.push(jQuery(this));
            }
            else
            {
                itemsSimple.push(jQuery(this));
                simpleItemsCount++;
            }
            countItems++;
        }
    });
    //Jei yra perkeliamu elementu
    if(countItems > 0)
    {
        $('li.has_submenu.more').show();
        var moreSub = jQuery('.more').find('.container.clra');
        var moreSubNoIcons = jQuery('.more').find('.side.no_icons');

        //perkeliam elementus su ikonom
        if(itemsWithIcons.length>0)
        {
            moreSub.prepend('<div class="side"><ul></ul></div>');
            var moreSubIcons = moreSub.find('.side:nth-child(1) > ul');
            itemsWithIcons.forEach(function(entry) {
                moreSubIcons.append(entry);
            });
        }

        //perkeliam elementus be ikonu
        if(simpleItemsCount>0)
        {
            half = parseInt(Math.ceil(parseInt(simpleItemsCount)/2));
            moreSubNoIcons.prepend('<ul></ul>');
            //Jei daugiau nei du elementai kuriam du stulpelius <ul>
            if(half>0)
            {
                moreSubNoIcons.prepend('<ul></ul>');
            }
            var tmp = 0;
            itemsSimple.forEach(function(entry){
                tmp++;
                if(tmp <= half) //elementai krentantys i pirma stulpeli
                {
                    moreSubNoIcons.children('ul:nth-child(1)').append(entry);
                }
                else //elementai krentantys i antra stulpeli
                {
                    moreSubNoIcons.children('ul:nth-child(2)').append(entry);
                }
            });

        }
    }
    else{
        $('li.has_submenu.more').hide();
    }
}
//---------------------------------------------------------

function closeCookiesMessage() {

    $( '.cookies' ).fadeOut( 300 );
}

function subscribeNews() {

    var form = $( '#subscribe_popup' );

    if ( form.find( 'input' ).val() === '' ) {

        form.addClass( 'error' );
    } else {

        form.removeClass( 'error' ).addClass( 'success' );

        setTimeout( function(){

            form.fadeOut( 300 );

            setTimeout( function(){

                $.magnificPopup.instance.close();
            }, 200);
        }, 1500);
    }
}

function submitForm(selector)
{
    $(selector).submit();
    return false;
}

// Charts

$( document ).ready( function(){

    var data = {
        labels: ["sausis", "vasaris", "kovas", "balandis", "gegužė", "birželis", "liepa", "rugpjūtis", "rugsėjis", "spalis", "lapkritis", "gruodis"],
        datasets: [
            {
                label: "2012",
                fillColor: "rgba(220,220,220,0.0)",
                strokeColor: "#e91e62",
                pointColor: "rgba(151,187,205,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [7500, 8000, 7500, 5000, 7500 ]
            },
            {
                label: "2013",
                fillColor: "rgba(220,220,220,0.0)",
                strokeColor: "#2095f3",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [12000, 13000, 25000, 4000, 2000, 15000, 12000, 13000, 25000, 4000, 20000, 25000 ]
            },
            {
                label: "2014",
                strokeColor: "#ffc106",
                pointColor: "rgba(151,187,205,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [18000, 22222, 18000, 22222, 18000, 22222, 18000, 22222, 18256, 21252, 18000, 10000 ]
            },
            {
                label: "2015",
                strokeColor: "#4bae50",
                pointColor: "rgba(151,187,205,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [17820, 5000, 21000, 14000, 18000, 17000, 22222, 25205, 18256, 21252, 25893, 5000 ]
            }
        ]
    };
    var data2 = {
        labels: ["sausis", "vasaris", "kovas", "balandis", "gegužė", "birželis", "liepa", "rugpjūtis", "rugsėjis", "spalis", "lapkritis", "gruodis"],
        datasets: [
            {
                label: "2012",
                fillColor: "rgba(220,220,220,0.0)",
                strokeColor: "#e91e62",
                pointColor: "rgba(151,187,205,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [10, 10, 10, 500, 0, 0, 0, 0, 50, 10, 10, 18000]
            },
            {
                label: "2013",
                fillColor: "rgba(220,220,220,0.0)",
                strokeColor: "#2095f3",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [12000, 13000,18000, 17000, 22222, 25205, 18256, 21252, 4000, 20000, 25000, 2000 ]
            },
            {
                label: "2014",
                strokeColor: "#ffc106",
                pointColor: "rgba(151,187,205,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [18000, 22222, 18000, 22222, 18000, 13000, 25000, 4000, 2000, 21252, 18000, 10000 ]
            },
            {
                label: "2015",
                strokeColor: "#4bae50",
                pointColor: "rgba(151,187,205,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [17820, 5000, 21000, 14000, 18000, 17000, 22222, 25205, 18256, 21252, 25893, 5000 ]
            }
        ]
    };

    var options = {
        animation: false,
        scaleShowVerticalLines: false,
        pointDot : false,
        bezierCurve : false,
        responsive: true,

        scaleFontFamily: "'Roboto'",
        scaleFontSize: 10,
        scaleFontColor: "#303030",
        showTooltips: false
    };

    if ( ($( '#chart1' ).length || $( '#chart2' ).length) && (typeof window.Chart != "undefined") ) {

        var ctx1 = document.getElementById("chart1").getContext("2d");
        var ctx2 = document.getElementById("chart2").getContext("2d");

        chart1 = new Chart(ctx1).Line(data, options);
        chart2 = new Chart(ctx2).Line(data2, options);
    }

    // Controls
    var controlItem = $( '.chart .controls .control label' );

    controlItem.on( 'click', function(event) {

        var chartName = eval( $( this ).parent().parent( '.controls' ).data( 'chartName' ) );
        var dataId = $( this ).data( 'id' );
        var dataColor = $( this ).data( 'color' );

        if ( chartName.datasets[dataId].strokeColor !== 'transparent' ) {

            chartName.datasets[dataId].strokeColor = 'transparent';
            chartName.update();
        } else {

            chartName.datasets[dataId].strokeColor = dataColor;
            chartName.update();
        }
    });

    // Nav

    $( '[data-target-tab]' ).on( 'click', function(){

        var jWrap = $(this).parents('.chart');
        if(jWrap.length)
        {
            var tabId = $( this ).data( 'targetTab' );

            jWrap.find('.charts_nav li').removeClass( 'active' );
            $( this ).addClass( 'active' );

            jWrap.find('.charts_holder [data-tab]').removeClass( 'active' );
            jWrap.find('.charts_holder [data-tab="' + tabId + '"]').addClass( 'active' );
        }
    });

    //

    $( '.ms_table_holder' ).on( 'scroll', function(){

        if ($( this ).scrollLeft() > 50 ) {

            $( this ).parent().addClass( 'act' );
        } else {

            $( this ).parent().removeClass( 'act' );
        }
    });

    //

    $('.header .d_only .search').on( 'click', function(){
        $(this).toggleClass('active');
    });
    $( '.header .d_only .search input' ).on( 'click', function(e){

        e.stopPropagation();
    });

    // Site tree

    $( '.item.has_sub .toggler' ).on( 'click', function(){

        $( this ).parent().toggleClass( 'active' );
        $( this ).parent().find( '.sub' ).slideToggle( 200 );
    });

    // Scroll Top

    $( '[data-scroll-top] > div' ).click( function(){

        $('html, body').animate({ scrollTop: 0 }, 500);
    });
});
//---------------------------------------------------------

function toggleRelevantInfo(that)
{
    var parent = $(that).parents('.container');
    var main_wrap = $(that).parents('.two_blocks');

    parent.find('>div').show();
    main_wrap.removeClass('hidden_content');
    $(that).hide();

    if((typeof $.scrollTo) != 'undefined')
    {
        $.scrollTo(main_wrap, 500);
    }

    return false;
}

//----------------------------------------------------------


$(document).ready(function() {

    $(".popup-overlay .close").click(function() {
        $('.popup-overlay').hide();
    });

    $('body').click(function(e) {
        if (!$(e.target).closest('.popup').length){
            $(".popup").hide();
            $(".popup-overlay").hide();
        }
    });

    $(".popup-overlay .popup").on('blur',function(){
        $(this).fadeOut(300);
    });

    if ($('html').is(':lang(en)')) {
        console.log($('.top_link').length);
        $('.main_services .top_link:nth-of-type(1)').addClass('full');
        $('.main_services .top_link:nth-of-type(2)').hide();
    }

})
